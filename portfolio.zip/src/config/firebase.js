// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
import { getAuth } from "firebase/auth";
import { getFirestore } from "firebase/firestore";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDJJG6uWUd0RjjX-rbeHxdn5zkJ6xJXY1g",
    authDomain: "porfolio-65b9d.firebaseapp.com",
    projectId: "porfolio-65b9d",
    storageBucket: "porfolio-65b9d.appspot.com",
    messagingSenderId: "16793165273",
    appId: "1:16793165273:web:521da4672c7ad2d502cdc8",
    measurementId: "G-NMDYXK8FNW"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const analytics = getAnalytics(app);
const db = getFirestore(app);
export { db, analytics }