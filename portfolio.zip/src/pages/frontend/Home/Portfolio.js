import React from 'react'
import { Image } from 'antd'
//icons
import WebAssetTwoToneIcon from '@mui/icons-material/WebAssetTwoTone';

import trendTrove from 'assets/final.6f670d232c94d4f07478.png'
import furniture from 'assets/furniture.b06c2a040955ba97d191.jpg'
import mobile from 'assets/ibadMobile.png'
import todo from 'assets/todo.png'
import eventPlanner from 'assets/event-planner.4bd8a5aef534b000f282.png'
import hackathon from 'assets/hackathon-project.png'




export default function Portfolio() {
  return (
    <div className='container' id='portfolio-section'>
      <h2 className='text-info text-center fw-bold my-5'>PORTFOLIO</h2>
      <div className="row row-cols-1 row-cols-sm-2 row-cols-md-3 g-4">
        <Image.PreviewGroup>
          <div className="col">
            <div className="card bg-dark">
              <div className="card-img rounded-0 rounded-top">
                <Image width="100%" className='inner-img' src={trendTrove} />
              </div>
              <div className="card-body">
                <a href="https://trend-troove.web.app/" target='_blank'>
                  <h3 className="card-title fw-bold text-info">Trend Trove</h3>
                </a>
                <p className="card-text d-flex justify-content-between">Web Design & Development
                  <WebAssetTwoToneIcon className='fs-1' />
                </p>
              </div>
            </div>
          </div>

          <div className="col">
            <div className="card bg-dark">
              <div className="card-img rounded-0 rounded-top">
                <Image width="100%" className='inner-img' src={furniture} />
              </div>
              <div className="card-body">
                <a href="https://furniture-site-6254.web.app/" target='_blank'>
                  <h3 className="card-title fw-bold text-info">Furniture Website</h3>
                </a>
                <p className="card-text d-flex justify-content-between">Web Design & Development
                  <WebAssetTwoToneIcon className='fs-1' />
                </p>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="card bg-dark">
              <div className="card-img rounded-0 rounded-top">
                <Image width="100%" className='inner-img' src={todo} />
              </div>
              <div className="card-body">
                <a href="https://tododo-seeeraht.surge.sh/" target='_blank'>
                  <h3 className="card-title fw-bold text-info">Todo Dashboard</h3>
                </a>
                <p className="card-text d-flex justify-content-between">Web Design & Development
                  <WebAssetTwoToneIcon className='fs-1' />
                </p>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="card bg-dark">
              <div className="card-img rounded-0 rounded-top">
                <Image width="100%" className='inner-img' src={mobile} />
              </div>
              <div className="card-body">
                <h3 className="card-title fw-bold text-info">Ibad Mobile</h3>
                <p className="card-text d-flex justify-content-between">Web Design & Development <WebAssetTwoToneIcon className='fs-1' /></p>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="card bg-dark">
              <div className="card-img rounded-0 rounded-top">
                <Image width="100%" className='inner-img' src={hackathon} />
              </div>
              <div className="card-body">
                <h3 className="card-title fw-bold text-info">IT Solutions</h3>
                <p className="card-text d-flex justify-content-between">Web Design & Development <WebAssetTwoToneIcon className='fs-1' /></p>
              </div>
            </div>
          </div>
          <div className="col">
            <div className="card bg-dark">
              <div className="card-img rounded-0 rounded-top">
                <Image width="100%" className='inner-img' src={eventPlanner} />
              </div>
              <div className="card-body">
                <h3 className="card-title fw-bold text-info">Event Planner</h3>
                <p className="card-text d-flex justify-content-between">Web Design & Development <WebAssetTwoToneIcon className='fs-1' /></p>
              </div>
            </div>
          </div>
        </Image.PreviewGroup >
      </div >
    </div >
  )
}
